<?php $pageTitle = 'Жоба туралы'; require_once __DIR__.'/includes/functions.php'; include __DIR__.'/includes/header.php'; ?>
<section class="panel"><h2>Жоба туралы</h2><p>«Менің қаржым» — кіріс пен шығынды бақылауға арналған веб-қосымша.</p><p>Бұл нұсқа PHP арқылы формаларды өңдейді, серверде деректерді тексереді және операцияларды сессияда сақтайды.</p><p><a href="index.php">← Басты бетке оралу</a></p></section>
<?php include __DIR__.'/includes/footer.php'; ?>
