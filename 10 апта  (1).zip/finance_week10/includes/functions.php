<?php
function e(string $value): string { return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function money(float $amount): string { return number_format($amount, 2, ',', ' ') . ' ₸'; }
function validDate(string $value): bool {
    $d = DateTimeImmutable::createFromFormat('!Y-m-d', $value);
    return $d !== false && $d->format('Y-m-d') === $value;
}
function redirectHome(): void { header('Location: index.php'); exit; }
