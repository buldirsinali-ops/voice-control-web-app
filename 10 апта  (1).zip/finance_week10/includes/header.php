<!DOCTYPE html>
<html lang="kk">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle ?? 'Менің қаржым') ?></title>
<link rel="stylesheet" href="style.css">
</head>
<body><div class="app">
<header><div><p class="subtitle">ЖЕКЕ ҚАРЖЫҢ</p><h1>Менің қаржым 💜</h1><p class="muted">Шығындарыңды бақыла</p></div><div class="logo">₸</div></header>
<nav class="site-nav"><a href="index.php">Басты бет</a> · <a href="about.php">Жоба туралы</a> · <a href="help.php">Көмек</a></nav>
