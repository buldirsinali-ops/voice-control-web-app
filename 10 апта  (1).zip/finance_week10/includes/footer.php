<footer>Менің қаржым © 2026</footer>
</div></body></html>
