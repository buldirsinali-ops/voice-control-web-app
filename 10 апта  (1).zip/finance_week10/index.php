<?php
session_start();
require_once __DIR__ . '/includes/functions.php';
if (!isset($_SESSION['operations'])) $_SESSION['operations'] = [];
if (!isset($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
$categories = ['Тамақ','Жол','Киім','Оқу','Денсаулық','Үй','Көңіл көтеру','Жалақы','Басқа'];
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf'], (string)($_POST['csrf'] ?? ''))) {
        http_response_code(403);
        $error = 'Қауіпсіздік тексерісі өтпеді. Бетті жаңартыңыз.';
    } else {
        $action = (string)($_POST['action'] ?? 'add');
        if ($action === 'add') {
            $type = (string)($_POST['type'] ?? '');
            $amount = filter_var($_POST['amount'] ?? null, FILTER_VALIDATE_FLOAT);
            $category = (string)($_POST['category'] ?? '');
            $description = trim((string)($_POST['description'] ?? ''));
            $date = (string)($_POST['date'] ?? '');
            if (!in_array($type, ['income','expense'], true) || $amount === false || !is_finite($amount) || $amount <= 0 || $amount > 1000000000000 || !in_array($category, $categories, true) || mb_strlen($description) > 150 || !validDate($date)) {
                $error = 'Мәліметтерді дұрыс толтырыңыз: сома оң сан, күн дұрыс болуы тиіс.';
            } else {
                $_SESSION['operations'][] = ['id'=>bin2hex(random_bytes(12)), 'type'=>$type, 'amount'=>(float)$amount, 'category'=>$category, 'description'=>$description, 'date'=>$date];
                redirectHome();
            }
        } elseif ($action === 'delete') {
            $id = (string)($_POST['id'] ?? '');
            $_SESSION['operations'] = array_values(array_filter($_SESSION['operations'], fn($op) => $op['id'] !== $id));
            redirectHome();
        } elseif ($action === 'clear') {
            $_SESSION['operations'] = [];
            redirectHome();
        } else { $error = 'Белгісіз әрекет.'; }
    }
}
$operations = $_SESSION['operations'];
$income = 0.0; $expense = 0.0; $todayExpense = 0.0; $monthExpense = 0.0;
$today = date('Y-m-d'); $month = date('Y-m');
foreach ($operations as $op) {
    if ($op['type'] === 'income') $income += $op['amount'];
    else {
        $expense += $op['amount'];
        if ($op['date'] === $today) $todayExpense += $op['amount'];
        if (substr($op['date'], 0, 7) === $month) $monthExpense += $op['amount'];
    }
}
$filter = (string)($_GET['type'] ?? 'all');
if (!in_array($filter, ['all','income','expense'], true)) $filter = 'all';
$visible = array_values(array_filter($operations, fn($op) => $filter === 'all' || $op['type'] === $filter));
usort($visible, fn($a, $b) => strcmp($b['date'], $a['date']));
$pageTitle = 'Менің қаржым — Басты бет';
include __DIR__ . '/includes/header.php';
?>
<section class="balance-card"><p>Жалпы баланс</p><h2 id="balance"><?= money($income - $expense) ?></h2><div class="balance-info"><div><span>↗ Кіріс</span><h3 id="income"><?= money($income) ?></h3></div><div><span>↘ Шығын</span><h3 id="expense"><?= money($expense) ?></h3></div></div></section>
<section class="stats"><div class="stat-card"><span>📅</span><p>Бүгінгі шығын</p><h3 id="todayExpense"><?= money($todayExpense) ?></h3></div><div class="stat-card"><span>📊</span><p>Осы айда</p><h3 id="monthExpense"><?= money($monthExpense) ?></h3></div></section>
<section class="panel"><h2>Жаңа операция</h2>
<?php if ($error !== ''): ?><p class="form-error" role="alert"><?= e($error) ?></p><?php endif; ?>
<form id="expenseForm" method="post" action="index.php">
<input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>"><input type="hidden" name="action" value="add">
<label for="type">Операция түрі</label><select id="type" name="type"><option value="expense">Шығын</option><option value="income">Кіріс</option></select>
<label for="amount">Сома (₸)</label><input type="number" id="amount" name="amount" placeholder="Мысалы: 2500" min="0.01" step="0.01" required>
<label for="category">Санат</label><select id="category" name="category"><?php foreach ($categories as $category): ?><option value="<?= e($category) ?>"><?= e($category) ?></option><?php endforeach; ?></select>
<label for="description">Сипаттамасы</label><input type="text" id="description" name="description" maxlength="150" placeholder="Мысалы: түскі ас">
<label for="date">Күні</label><input type="date" id="date" name="date" value="<?= e($today) ?>" required>
<button type="submit" class="add-btn">+ Операция қосу</button></form></section>
<section class="panel"><div class="history-header"><h2>Операциялар тарихы</h2><form method="post" onsubmit="return confirm('Барлық операцияны өшіргің келе ме?')"><input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>"><input type="hidden" name="action" value="clear"><button type="submit" id="clearBtn" class="clear-btn">Тазарту</button></form></div>
<form method="get" class="filter-form"><label for="filter">Сүзу:</label><select id="filter" name="type"><option value="all" <?= $filter==='all'?'selected':'' ?>>Барлығы</option><option value="income" <?= $filter==='income'?'selected':'' ?>>Кіріс</option><option value="expense" <?= $filter==='expense'?'selected':'' ?>>Шығын</option></select><button type="submit" class="add-btn">Көрсету</button></form>
<div id="history" class="history">
<?php if (!$visible): ?><p class="empty">Әзірге операциялар жоқ</p><?php else: foreach ($visible as $op): ?>
<div class="history-item"><div class="history-icon"><?= $op['type']==='income'?'↗':'↘' ?></div><div class="history-details"><h4><?= e($op['description'] ?: $op['category']) ?></h4><p><?= e($op['category']) ?> • <?= e($op['date']) ?></p></div><div class="history-amount <?= $op['type']==='income'?'positive':'negative' ?>"><?= $op['type']==='income'?'+':'−' ?><?= money($op['amount']) ?></div><form method="post"><input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= e($op['id']) ?>"><button type="submit" class="delete-btn" aria-label="Өшіру">×</button></form></div>
<?php endforeach; endif; ?></div></section>
<?php include __DIR__ . '/includes/footer.php'; ?>
